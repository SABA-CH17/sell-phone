<?php
include("include/db-connect.php");
include("include/auth-check.php");
require_once('include/a-header.php');

$brand_filter = trim($_GET['brand'] ?? '');
$status_filter = trim($_GET['status'] ?? '');
$search = trim($_GET['search'] ?? '');

$where = [];
$params = [];
$types = '';

if ($brand_filter !== '') {
    $where[] = "brand = ?";
    $params[] = $brand_filter;
    $types .= 's';
}
if ($status_filter !== '') {
    $where[] = "status = ?";
    $params[] = $status_filter;
    $types .= 's';
}
if ($search !== '') {
    $where[] = "(name LIKE ? OR phone LIKE ?)";
    $like = "%$search%";
    $params[] = $like;
    $params[] = $like;
    $types .= 'ss';
}

$sql = "SELECT * FROM leads";
if (!empty($where)) {
    $sql .= " WHERE " . implode(" AND ", $where);
}
$sql .= " ORDER BY created_at DESC";

$leads = [];
if (!empty($params)) {
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, $types, ...$params);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
} else {
    $result = mysqli_query($conn, $sql);
}
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $leads[] = $row;
    }
}

$brands = [];
$brand_result = mysqli_query($conn, "SELECT DISTINCT brand FROM leads WHERE brand IS NOT NULL AND brand <> '' ORDER BY brand");
if ($brand_result) {
    while ($b = mysqli_fetch_assoc($brand_result)) {
        $brands[] = $b['brand'];
    }
}
?>
<?php require_once('section/sidebar.php'); ?>
<div class="main-content">
    <div class="content-header">
        <div>
            <h1 class="main-h1">Leads</h1>
            <p class="current-date">Manage all sell-phone submissions</p>
        </div>
        <div class="admin-avatar">AD</div>
    </div>

    <form method="GET" action="leads.php" class="d-flex flex-wrap gap-2 align-items-center mb-4">
        <div class="input-group flex-nowrap" style="max-width:260px; height:30px; border-radius:2px;">
            <input type="text" name="search" class="form-control" placeholder="Search by name or phone..."
                aria-label="Search" value="<?php echo htmlspecialchars($search); ?>">
        </div>

        <select name="brand" class="form-select form-select-sm" style="max-width:180px; margin-bottom:5px;" onchange="this.form.submit()">
            <option value="">All brands</option>
            <?php foreach ($brands as $b): ?>
                <option value="<?php echo htmlspecialchars($b); ?>" <?php echo ($brand_filter === $b) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($b); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <select name="status" class="form-select form-select-sm" style="max-width:180px;" onchange="this.form.submit()">
            <option value="">All status</option>
            <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>Pending</option>
            <option value="contacted" <?php echo $status_filter === 'contacted' ? 'selected' : ''; ?>>Contacted</option>
            <option value="completed" <?php echo $status_filter === 'completed' ? 'selected' : ''; ?>>Completed</option>
        </select>

        <button type="submit" class="btn btn-sm" style="background:#0B1E3F; color:#fff;">Filter</button>
        <?php if ($brand_filter !== '' || $status_filter !== '' || $search !== ''): ?>
            <a href="leads.php" class="btn btn-sm btn-secondary">Clear</a>
        <?php endif; ?>
    </form>

    <div class="leads-tables-wrap">
        <table class="leads-tables">
                <tr>
                    <th>Image</th>
                    <th>Order #</th>
                    <th>Name</th>
                    <th>Model</th>
                    <th>Storage</th>
                    <th>Price</th>
                    <th>Phone</th>
                    <th>Date</th>
                    <th>Status</th>
                </tr>
            <?php if (empty($leads)): ?>
                <tr>
                    <td colspan="9" style="text-align:center; padding:16px; color:#797979c5;">No leads found.</td>
            <?php else: ?>
                <?php foreach ($leads as $lead): ?>
                    <tr>
                        <td>
            <?php if (!empty($lead['image'])): ?>
                <img src="../<?php echo htmlspecialchars($lead['image']); ?>"
               alt="<?php echo htmlspecialchars($lead['model'] ?? ''); ?>"
              style="width:40px; height:40px; object-fit:cover; border-radius:6px;">
             <?php else: ?>
                <span class="text-muted">—</span>
            <?php endif; ?>
        </td>
                        <td><?php echo htmlspecialchars($lead['order_number']); ?>
                    </td>
                        <td><?php echo htmlspecialchars($lead['name'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($lead['model'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($lead['storage'] ?? ''); ?></td>
                        <td>AED <?php echo number_format((float) ($lead['price'] ?? 0), 0); ?></td>
                        <td><?php echo htmlspecialchars($lead['phone'] ?? ''); ?></td>
                        <td><?php echo !empty($lead['created_at']) ? htmlspecialchars(date("M j", strtotime($lead['created_at']))) : ''; ?></td>
                        <td>
                            <select class="form-select-value form-select-sm status-select"
                                data-status="<?php echo htmlspecialchars($lead['status'] ?? 'pending'); ?>"
                                data-id="<?php echo (int) $lead['id']; ?>">
                                <option value="pending" <?php echo ($lead['status'] ?? '') === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                <option value="contacted" <?php echo ($lead['status'] ?? '') === 'contacted' ? 'selected' : ''; ?>>Contacted</option>
                                <option value="completed" <?php echo ($lead['status'] ?? '') === 'completed' ? 'selected' : ''; ?>>Completed</option>
                            </select>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </table>

    </div>

    <ul class="pagination pagination-sm justify-content-center mt-4 ">
        <li class="page-item active">
            <a class="page-link" style="background-color:#0B1E3F; border-color:#0B1E3F; color:white;"
                aria-current="page">1</a>
                
        </li>
    </ul>

</div>
</body>

</html>
