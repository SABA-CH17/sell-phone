<?php
include("include/db-connect.php");
include("include/auth-check.php");

$success_msg = "";
$error_msg = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_admin'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($username === '' || $password === '') {
        $error_msg = "Username and password are required.";
    } elseif ($password !== $confirm_password) {
        $error_msg = "Password and Confirm Password do not match.";
    } elseif (strlen($password) < 8) {
        $error_msg = "Password must be at least 8 characters long.";
    } else {
        // check if username already exists
        $check = mysqli_prepare($conn, "SELECT id FROM admin_user WHERE username = ?");
        mysqli_stmt_bind_param($check, "s", $username);
        mysqli_stmt_execute($check);
        mysqli_stmt_store_result($check);

        if (mysqli_stmt_num_rows($check) > 0) {
            $error_msg = "This username already exists.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = mysqli_prepare($conn, "INSERT INTO admin_user (username, password) VALUES (?, ?)");
            mysqli_stmt_bind_param($stmt, "ss", $username, $hashed_password);

            if (mysqli_stmt_execute($stmt)) {
                $success_msg = "New admin '$username' was added successfully.";
            } else {
                $error_msg = "Could not add admin: " . mysqli_error($conn);
            }
        }
        mysqli_stmt_close($check);
    }
}

if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    $current_username = $_SESSION['admin_username'] ?? null;

    $self_check = mysqli_prepare($conn, "SELECT username FROM admin_user WHERE id = ?");
    mysqli_stmt_bind_param($self_check, "i", $id);
    mysqli_stmt_execute($self_check);
    $self_result = mysqli_stmt_get_result($self_check);
    $target = mysqli_fetch_assoc($self_result);

    if (!$target) {
        $error_msg = "Admin not found (id: $id).";
    } elseif ($current_username !== null && $target['username'] === $current_username) {
        $error_msg = "You cannot delete your own currently logged-in account.";
    } else {
        $del = mysqli_prepare($conn, "DELETE FROM admin_user WHERE id = ?");
        mysqli_stmt_bind_param($del, "i", $id);
        if (mysqli_stmt_execute($del)) {
            header("Location: admin-users.php?deleted=1");
            exit;
        } else {
            $error_msg = "Delete failed: " . mysqli_error($conn);
        }
    }
}

require_once('include/a-header.php');
require_once('section/sidebar.php');

$admins = [];
$result = mysqli_query($conn, "SELECT * FROM admin_user ORDER BY id ASC");
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $admins[] = $row;
    }
}
?>

<div class="main-content">
    <div class="content-header">
        <div>
            <h1 class="main-h1">Admin Users</h1>
            <p class="current-date">Manage dashboard admin accounts</p>
        </div>
        <div class="admin-avatar">AD</div>
    </div>

    <?php if (isset($_GET['deleted'])): ?>
        <div class="alert alert-success" style="border-radius:10px;">Admin was deleted successfully.</div>
    <?php endif; ?>
    <?php if ($success_msg): ?>
        <div class="alert alert-success" style="border-radius:10px;"><?php echo $success_msg; ?></div>
    <?php endif; ?>
    <?php if ($error_msg): ?>
        <div class="alert alert-danger" style="border-radius:10px;"><?php echo $error_msg; ?></div>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                new bootstrap.Modal(document.getElementById('addAdminModal')).show();
            });
        </script>
    <?php endif; ?>

    <div class="d-flex justify-content-end mb-4">
        <button type="button" class="btn" style="background-color:#0B1E3F; color:#fff;"
            data-bs-toggle="modal" data-bs-target="#addAdminModal">
            <i class="fa-solid fa-user-plus me-1"></i> Add New Admin
        </button>
    </div>

    <!-- Add Admin Modal -->
    <div class="modal fade" id="addAdminModal" tabindex="-1" aria-labelledby="addAdminModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content" style="border-radius:14px;">
                <form method="POST" action="admin-users.php">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="addAdminModalLabel">
                            <i class="fa-solid fa-user-plus me-2"></i>Add new admin
                        </h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label" style="font-size:12.5px; color:#797979c5;">Username</label>
                                <input type="text" name="username" class="form-control" placeholder="Username" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label" style="font-size:12.5px; color:#797979c5;">Password</label>
                                <input type="password" name="password" class="form-control" placeholder="Password" required minlength="6">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label" style="font-size:12.5px; color:#797979c5;">Confirm Password</label>
                                <input type="password" name="confirm_password" class="form-control" placeholder="Confirm Password" required minlength="6">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="add_admin" class="btn"
                            style="background:#0B1E3F; color:#fff;">Add Admin</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="table-responsive" style="border:1px solid #eef1f5; border-radius:14px;">
        <table class="table align-middle mb-0" style="font-size:13px;">
            <thead style="background:#f9fafb;">
                <tr>
                    <th style="color:#0B1E3F;">ID</th>
                    <th style="color:#0B1E3F;">Username</th>
                    <th class="text-center" style="color:#0B1E3F;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($admins)): ?>
                    <tr><td colspan="3" class="text-center text-muted py-3">No admins found.</td></tr>
                <?php else: ?>
                    <?php foreach ($admins as $a): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($a['id']); ?></td>
                            <td class="fw-semibold" style="color:#333;"><?php echo htmlspecialchars($a['username']); ?></td>
                            <td class="text-center">
                                <a href="admin-users.php?delete=<?php echo (int) $a['id']; ?>"
                                   class="btn btn-sm delete-btn"
                                   style="background:#fdeaea; color:#c0392b; border:none;"
                                   onclick="return confirm('Are you sure you want to delete this admin?');">
                                   <i class="fa-solid fa-trash"></i> Delete
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
