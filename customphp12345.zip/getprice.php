<?php

echo "test";
// require_once("admin/include/db-connect.php");
// header('Content-Type: application/json');

// $model_id = (int) ($_POST['model_id'] ?? 0);
// $storage_key = $_POST['storage'] ?? '';
// $condition_key = $_POST['condition'] ?? '';
// $accessories = $_POST['accessories'] ?? [];
// $allowed_storage = ['storage_128', 'storage_256', 'storage_512'];
// $allowed_condition = ['condition_flawless', 'condition_good', 'condition_fair'];
// $allowed_accessories = ['acc_charger', 'acc_box', 'acc_earbuds', 'acc_warranty'];

// if (!$model_id || !in_array($storage_key, $allowed_storage) || !in_array($condition_key, $allowed_condition)) {
//     http_response_code(400);
//     echo json_encode(["error" => "Missing or invalid selection."]);
//     exit;
// }

// $stmt = mysqli_prepare($conn, "SELECT * FROM model_pricing WHERE model_id = ?");
// mysqli_stmt_bind_param($stmt, "i", $model_id);
// mysqli_stmt_execute($stmt);
// $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

// if (!$row) {
//     echo json_encode(["price" => 0, "note" => "No pricing has been set for this model yet."]);
//     exit;
// }

// $price = (float) $row['base'] + (float) $row[$storage_key] + (float) $row[$condition_key];

// foreach ($accessories as $acc) {
//     if (in_array($acc, $allowed_accessories)) {
//         $price += (float) $row[$acc];
//     }
// }

// echo json_encode(["price" => max(0, $price)]);