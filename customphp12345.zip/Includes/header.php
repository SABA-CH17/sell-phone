<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SellMobileDubai</title>
    <?php include ("links.php"); ?>
</head>
<body>
    <?php require_once("navbar.php"); ?>